﻿using System;
using System.Data;
using System.Text;
using System.Data.SqlClient;
using Maticsoft.IDAL;
using Maticsoft.DBUtility;//Please add references
namespace Maticsoft.SQLServerDAL
{
	/// <summary>
	/// 数据访问类:TeacherTable1
	/// </summary>
	public partial class TeacherTable1:ITeacherTable1
	{
		public TeacherTable1()
		{}
		#region  BasicMethod

		/// <summary>
		/// 是否存在该记录
		/// </summary>
		public bool Exists(string TeacherID)
		{
			StringBuilder strSql=new StringBuilder();
			strSql.Append("select count(1) from TeacherTable1");
			strSql.Append(" where TeacherID=SQL2012TeacherID ");
			SqlParameter[] parameters = {
					new SqlParameter("SQL2012TeacherID", SqlDbType.NChar,10)			};
			parameters[0].Value = TeacherID;

			return DbHelperSQL.Exists(strSql.ToString(),parameters);
		}


		/// <summary>
		/// 增加一条数据
		/// </summary>
		public bool Add(Maticsoft.Model.TeacherTable1 model)
		{
			StringBuilder strSql=new StringBuilder();
			strSql.Append("insert into TeacherTable1(");
			strSql.Append("TeacherID,TeacherName,TeacherSex,TeacherBirthday,Post,Department)");
			strSql.Append(" values (");
			strSql.Append("SQL2012TeacherID,SQL2012TeacherName,SQL2012TeacherSex,SQL2012TeacherBirthday,SQL2012Post,SQL2012Department)");
			SqlParameter[] parameters = {
					new SqlParameter("SQL2012TeacherID", SqlDbType.NChar,10),
					new SqlParameter("SQL2012TeacherName", SqlDbType.NChar,10),
					new SqlParameter("SQL2012TeacherSex", SqlDbType.NChar,2),
					new SqlParameter("SQL2012TeacherBirthday", SqlDbType.DateTime),
					new SqlParameter("SQL2012Post", SqlDbType.NChar,10),
					new SqlParameter("SQL2012Department", SqlDbType.NChar,20)};
			parameters[0].Value = model.TeacherID;
			parameters[1].Value = model.TeacherName;
			parameters[2].Value = model.TeacherSex;
			parameters[3].Value = model.TeacherBirthday;
			parameters[4].Value = model.Post;
			parameters[5].Value = model.Department;

			int rows=DbHelperSQL.ExecuteSql(strSql.ToString(),parameters);
			if (rows > 0)
			{
				return true;
			}
			else
			{
				return false;
			}
		}
		/// <summary>
		/// 更新一条数据
		/// </summary>
		public bool Update(Maticsoft.Model.TeacherTable1 model)
		{
			StringBuilder strSql=new StringBuilder();
			strSql.Append("update TeacherTable1 set ");
			strSql.Append("TeacherName=SQL2012TeacherName,");
			strSql.Append("TeacherSex=SQL2012TeacherSex,");
			strSql.Append("TeacherBirthday=SQL2012TeacherBirthday,");
			strSql.Append("Post=SQL2012Post,");
			strSql.Append("Department=SQL2012Department");
			strSql.Append(" where TeacherID=SQL2012TeacherID ");
			SqlParameter[] parameters = {
					new SqlParameter("SQL2012TeacherName", SqlDbType.NChar,10),
					new SqlParameter("SQL2012TeacherSex", SqlDbType.NChar,2),
					new SqlParameter("SQL2012TeacherBirthday", SqlDbType.DateTime),
					new SqlParameter("SQL2012Post", SqlDbType.NChar,10),
					new SqlParameter("SQL2012Department", SqlDbType.NChar,20),
					new SqlParameter("SQL2012TeacherID", SqlDbType.NChar,10)};
			parameters[0].Value = model.TeacherName;
			parameters[1].Value = model.TeacherSex;
			parameters[2].Value = model.TeacherBirthday;
			parameters[3].Value = model.Post;
			parameters[4].Value = model.Department;
			parameters[5].Value = model.TeacherID;

			int rows=DbHelperSQL.ExecuteSql(strSql.ToString(),parameters);
			if (rows > 0)
			{
				return true;
			}
			else
			{
				return false;
			}
		}

		/// <summary>
		/// 删除一条数据
		/// </summary>
		public bool Delete(string TeacherID)
		{
			
			StringBuilder strSql=new StringBuilder();
			strSql.Append("delete from TeacherTable1 ");
			strSql.Append(" where TeacherID=SQL2012TeacherID ");
			SqlParameter[] parameters = {
					new SqlParameter("SQL2012TeacherID", SqlDbType.NChar,10)			};
			parameters[0].Value = TeacherID;

			int rows=DbHelperSQL.ExecuteSql(strSql.ToString(),parameters);
			if (rows > 0)
			{
				return true;
			}
			else
			{
				return false;
			}
		}
		/// <summary>
		/// 批量删除数据
		/// </summary>
		public bool DeleteList(string TeacherIDlist )
		{
			StringBuilder strSql=new StringBuilder();
			strSql.Append("delete from TeacherTable1 ");
			strSql.Append(" where TeacherID in ("+TeacherIDlist + ")  ");
			int rows=DbHelperSQL.ExecuteSql(strSql.ToString());
			if (rows > 0)
			{
				return true;
			}
			else
			{
				return false;
			}
		}


		/// <summary>
		/// 得到一个对象实体
		/// </summary>
		public Maticsoft.Model.TeacherTable1 GetModel(string TeacherID)
		{
			
			StringBuilder strSql=new StringBuilder();
			strSql.Append("select  top 1 TeacherID,TeacherName,TeacherSex,TeacherBirthday,Post,Department from TeacherTable1 ");
			strSql.Append(" where TeacherID=SQL2012TeacherID ");
			SqlParameter[] parameters = {
					new SqlParameter("SQL2012TeacherID", SqlDbType.NChar,10)			};
			parameters[0].Value = TeacherID;

			Maticsoft.Model.TeacherTable1 model=new Maticsoft.Model.TeacherTable1();
			DataSet ds=DbHelperSQL.Query(strSql.ToString(),parameters);
			if(ds.Tables[0].Rows.Count>0)
			{
				return DataRowToModel(ds.Tables[0].Rows[0]);
			}
			else
			{
				return null;
			}
		}


		/// <summary>
		/// 得到一个对象实体
		/// </summary>
		public Maticsoft.Model.TeacherTable1 DataRowToModel(DataRow row)
		{
			Maticsoft.Model.TeacherTable1 model=new Maticsoft.Model.TeacherTable1();
			if (row != null)
			{
				if(row["TeacherID"]!=null)
				{
					model.TeacherID=row["TeacherID"].ToString();
				}
				if(row["TeacherName"]!=null)
				{
					model.TeacherName=row["TeacherName"].ToString();
				}
				if(row["TeacherSex"]!=null)
				{
					model.TeacherSex=row["TeacherSex"].ToString();
				}
				if(row["TeacherBirthday"]!=null && row["TeacherBirthday"].ToString()!="")
				{
					model.TeacherBirthday=DateTime.Parse(row["TeacherBirthday"].ToString());
				}
				if(row["Post"]!=null)
				{
					model.Post=row["Post"].ToString();
				}
				if(row["Department"]!=null)
				{
					model.Department=row["Department"].ToString();
				}
			}
			return model;
		}

		/// <summary>
		/// 获得数据列表
		/// </summary>
		public DataSet GetList(string strWhere)
		{
			StringBuilder strSql=new StringBuilder();
			strSql.Append("select TeacherID,TeacherName,TeacherSex,TeacherBirthday,Post,Department ");
			strSql.Append(" FROM TeacherTable1 ");
			if(strWhere.Trim()!="")
			{
				strSql.Append(" where "+strWhere);
			}
			return DbHelperSQL.Query(strSql.ToString());
		}

		/// <summary>
		/// 获得前几行数据
		/// </summary>
		public DataSet GetList(int Top,string strWhere,string filedOrder)
		{
			StringBuilder strSql=new StringBuilder();
			strSql.Append("select ");
			if(Top>0)
			{
				strSql.Append(" top "+Top.ToString());
			}
			strSql.Append(" TeacherID,TeacherName,TeacherSex,TeacherBirthday,Post,Department ");
			strSql.Append(" FROM TeacherTable1 ");
			if(strWhere.Trim()!="")
			{
				strSql.Append(" where "+strWhere);
			}
			strSql.Append(" order by " + filedOrder);
			return DbHelperSQL.Query(strSql.ToString());
		}

		/// <summary>
		/// 获取记录总数
		/// </summary>
		public int GetRecordCount(string strWhere)
		{
			StringBuilder strSql=new StringBuilder();
			strSql.Append("select count(1) FROM TeacherTable1 ");
			if(strWhere.Trim()!="")
			{
				strSql.Append(" where "+strWhere);
			}
			object obj = DbHelperSQL.GetSingle(strSql.ToString());
			if (obj == null)
			{
				return 0;
			}
			else
			{
				return Convert.ToInt32(obj);
			}
		}
		/// <summary>
		/// 分页获取数据列表
		/// </summary>
		public DataSet GetListByPage(string strWhere, string orderby, int startIndex, int endIndex)
		{
			StringBuilder strSql=new StringBuilder();
			strSql.Append("SELECT * FROM ( ");
			strSql.Append(" SELECT ROW_NUMBER() OVER (");
			if (!string.IsNullOrEmpty(orderby.Trim()))
			{
				strSql.Append("order by T." + orderby );
			}
			else
			{
				strSql.Append("order by T.TeacherID desc");
			}
			strSql.Append(")AS Row, T.*  from TeacherTable1 T ");
			if (!string.IsNullOrEmpty(strWhere.Trim()))
			{
				strSql.Append(" WHERE " + strWhere);
			}
			strSql.Append(" ) TT");
			strSql.AppendFormat(" WHERE TT.Row between {0} and {1}", startIndex, endIndex);
			return DbHelperSQL.Query(strSql.ToString());
		}

		/*
		/// <summary>
		/// 分页获取数据列表
		/// </summary>
		public DataSet GetList(int PageSize,int PageIndex,string strWhere)
		{
			SqlParameter[] parameters = {
					new SqlParameter("SQL2012tblName", SqlDbType.VarChar, 255),
					new SqlParameter("SQL2012fldName", SqlDbType.VarChar, 255),
					new SqlParameter("SQL2012PageSize", SqlDbType.Int),
					new SqlParameter("SQL2012PageIndex", SqlDbType.Int),
					new SqlParameter("SQL2012IsReCount", SqlDbType.Bit),
					new SqlParameter("SQL2012OrderType", SqlDbType.Bit),
					new SqlParameter("SQL2012strWhere", SqlDbType.VarChar,1000),
					};
			parameters[0].Value = "TeacherTable1";
			parameters[1].Value = "TeacherID";
			parameters[2].Value = PageSize;
			parameters[3].Value = PageIndex;
			parameters[4].Value = 0;
			parameters[5].Value = 0;
			parameters[6].Value = strWhere;	
			return DbHelperSQL.RunProcedure("UP_GetRecordByPage",parameters,"ds");
		}*/

		#endregion  BasicMethod
		#region  ExtensionMethod

		#endregion  ExtensionMethod
	}
}

