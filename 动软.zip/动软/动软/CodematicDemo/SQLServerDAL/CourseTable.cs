﻿using System;
using System.Data;
using System.Text;
using System.Data.SqlClient;
using Maticsoft.IDAL;
using Maticsoft.DBUtility;//Please add references
namespace Maticsoft.SQLServerDAL
{
	/// <summary>
	/// 数据访问类:CourseTable
	/// </summary>
	public partial class CourseTable:ICourseTable
	{
		public CourseTable()
		{}
		#region  BasicMethod

		/// <summary>
		/// 是否存在该记录
		/// </summary>
		public bool Exists(string CourseID)
		{
			StringBuilder strSql=new StringBuilder();
			strSql.Append("select count(1) from CourseTable");
			strSql.Append(" where CourseID=SQL2012CourseID ");
			SqlParameter[] parameters = {
					new SqlParameter("SQL2012CourseID", SqlDbType.NChar,16)			};
			parameters[0].Value = CourseID;

			return DbHelperSQL.Exists(strSql.ToString(),parameters);
		}


		/// <summary>
		/// 增加一条数据
		/// </summary>
		public bool Add(Maticsoft.Model.CourseTable model)
		{
			StringBuilder strSql=new StringBuilder();
			strSql.Append("insert into CourseTable(");
			strSql.Append("CourseID,CourseName,Point,StuNumber)");
			strSql.Append(" values (");
			strSql.Append("SQL2012CourseID,SQL2012CourseName,SQL2012Point,SQL2012StuNumber)");
			SqlParameter[] parameters = {
					new SqlParameter("SQL2012CourseID", SqlDbType.NChar,16),
					new SqlParameter("SQL2012CourseName", SqlDbType.NChar,16),
					new SqlParameter("SQL2012Point", SqlDbType.NChar,8),
					new SqlParameter("SQL2012StuNumber", SqlDbType.DateTime)};
			parameters[0].Value = model.CourseID;
			parameters[1].Value = model.CourseName;
			parameters[2].Value = model.Point;
			parameters[3].Value = model.StuNumber;

			int rows=DbHelperSQL.ExecuteSql(strSql.ToString(),parameters);
			if (rows > 0)
			{
				return true;
			}
			else
			{
				return false;
			}
		}
		/// <summary>
		/// 更新一条数据
		/// </summary>
		public bool Update(Maticsoft.Model.CourseTable model)
		{
			StringBuilder strSql=new StringBuilder();
			strSql.Append("update CourseTable set ");
			strSql.Append("CourseName=SQL2012CourseName,");
			strSql.Append("Point=SQL2012Point,");
			strSql.Append("StuNumber=SQL2012StuNumber");
			strSql.Append(" where CourseID=SQL2012CourseID ");
			SqlParameter[] parameters = {
					new SqlParameter("SQL2012CourseName", SqlDbType.NChar,16),
					new SqlParameter("SQL2012Point", SqlDbType.NChar,8),
					new SqlParameter("SQL2012StuNumber", SqlDbType.DateTime),
					new SqlParameter("SQL2012CourseID", SqlDbType.NChar,16)};
			parameters[0].Value = model.CourseName;
			parameters[1].Value = model.Point;
			parameters[2].Value = model.StuNumber;
			parameters[3].Value = model.CourseID;

			int rows=DbHelperSQL.ExecuteSql(strSql.ToString(),parameters);
			if (rows > 0)
			{
				return true;
			}
			else
			{
				return false;
			}
		}

		/// <summary>
		/// 删除一条数据
		/// </summary>
		public bool Delete(string CourseID)
		{
			
			StringBuilder strSql=new StringBuilder();
			strSql.Append("delete from CourseTable ");
			strSql.Append(" where CourseID=SQL2012CourseID ");
			SqlParameter[] parameters = {
					new SqlParameter("SQL2012CourseID", SqlDbType.NChar,16)			};
			parameters[0].Value = CourseID;

			int rows=DbHelperSQL.ExecuteSql(strSql.ToString(),parameters);
			if (rows > 0)
			{
				return true;
			}
			else
			{
				return false;
			}
		}
		/// <summary>
		/// 批量删除数据
		/// </summary>
		public bool DeleteList(string CourseIDlist )
		{
			StringBuilder strSql=new StringBuilder();
			strSql.Append("delete from CourseTable ");
			strSql.Append(" where CourseID in ("+CourseIDlist + ")  ");
			int rows=DbHelperSQL.ExecuteSql(strSql.ToString());
			if (rows > 0)
			{
				return true;
			}
			else
			{
				return false;
			}
		}


		/// <summary>
		/// 得到一个对象实体
		/// </summary>
		public Maticsoft.Model.CourseTable GetModel(string CourseID)
		{
			
			StringBuilder strSql=new StringBuilder();
			strSql.Append("select  top 1 CourseID,CourseName,Point,StuNumber from CourseTable ");
			strSql.Append(" where CourseID=SQL2012CourseID ");
			SqlParameter[] parameters = {
					new SqlParameter("SQL2012CourseID", SqlDbType.NChar,16)			};
			parameters[0].Value = CourseID;

			Maticsoft.Model.CourseTable model=new Maticsoft.Model.CourseTable();
			DataSet ds=DbHelperSQL.Query(strSql.ToString(),parameters);
			if(ds.Tables[0].Rows.Count>0)
			{
				return DataRowToModel(ds.Tables[0].Rows[0]);
			}
			else
			{
				return null;
			}
		}


		/// <summary>
		/// 得到一个对象实体
		/// </summary>
		public Maticsoft.Model.CourseTable DataRowToModel(DataRow row)
		{
			Maticsoft.Model.CourseTable model=new Maticsoft.Model.CourseTable();
			if (row != null)
			{
				if(row["CourseID"]!=null)
				{
					model.CourseID=row["CourseID"].ToString();
				}
				if(row["CourseName"]!=null)
				{
					model.CourseName=row["CourseName"].ToString();
				}
				if(row["Point"]!=null)
				{
					model.Point=row["Point"].ToString();
				}
				if(row["StuNumber"]!=null && row["StuNumber"].ToString()!="")
				{
					model.StuNumber=DateTime.Parse(row["StuNumber"].ToString());
				}
			}
			return model;
		}

		/// <summary>
		/// 获得数据列表
		/// </summary>
		public DataSet GetList(string strWhere)
		{
			StringBuilder strSql=new StringBuilder();
			strSql.Append("select CourseID,CourseName,Point,StuNumber ");
			strSql.Append(" FROM CourseTable ");
			if(strWhere.Trim()!="")
			{
				strSql.Append(" where "+strWhere);
			}
			return DbHelperSQL.Query(strSql.ToString());
		}

		/// <summary>
		/// 获得前几行数据
		/// </summary>
		public DataSet GetList(int Top,string strWhere,string filedOrder)
		{
			StringBuilder strSql=new StringBuilder();
			strSql.Append("select ");
			if(Top>0)
			{
				strSql.Append(" top "+Top.ToString());
			}
			strSql.Append(" CourseID,CourseName,Point,StuNumber ");
			strSql.Append(" FROM CourseTable ");
			if(strWhere.Trim()!="")
			{
				strSql.Append(" where "+strWhere);
			}
			strSql.Append(" order by " + filedOrder);
			return DbHelperSQL.Query(strSql.ToString());
		}

		/// <summary>
		/// 获取记录总数
		/// </summary>
		public int GetRecordCount(string strWhere)
		{
			StringBuilder strSql=new StringBuilder();
			strSql.Append("select count(1) FROM CourseTable ");
			if(strWhere.Trim()!="")
			{
				strSql.Append(" where "+strWhere);
			}
			object obj = DbHelperSQL.GetSingle(strSql.ToString());
			if (obj == null)
			{
				return 0;
			}
			else
			{
				return Convert.ToInt32(obj);
			}
		}
		/// <summary>
		/// 分页获取数据列表
		/// </summary>
		public DataSet GetListByPage(string strWhere, string orderby, int startIndex, int endIndex)
		{
			StringBuilder strSql=new StringBuilder();
			strSql.Append("SELECT * FROM ( ");
			strSql.Append(" SELECT ROW_NUMBER() OVER (");
			if (!string.IsNullOrEmpty(orderby.Trim()))
			{
				strSql.Append("order by T." + orderby );
			}
			else
			{
				strSql.Append("order by T.CourseID desc");
			}
			strSql.Append(")AS Row, T.*  from CourseTable T ");
			if (!string.IsNullOrEmpty(strWhere.Trim()))
			{
				strSql.Append(" WHERE " + strWhere);
			}
			strSql.Append(" ) TT");
			strSql.AppendFormat(" WHERE TT.Row between {0} and {1}", startIndex, endIndex);
			return DbHelperSQL.Query(strSql.ToString());
		}

		/*
		/// <summary>
		/// 分页获取数据列表
		/// </summary>
		public DataSet GetList(int PageSize,int PageIndex,string strWhere)
		{
			SqlParameter[] parameters = {
					new SqlParameter("SQL2012tblName", SqlDbType.VarChar, 255),
					new SqlParameter("SQL2012fldName", SqlDbType.VarChar, 255),
					new SqlParameter("SQL2012PageSize", SqlDbType.Int),
					new SqlParameter("SQL2012PageIndex", SqlDbType.Int),
					new SqlParameter("SQL2012IsReCount", SqlDbType.Bit),
					new SqlParameter("SQL2012OrderType", SqlDbType.Bit),
					new SqlParameter("SQL2012strWhere", SqlDbType.VarChar,1000),
					};
			parameters[0].Value = "CourseTable";
			parameters[1].Value = "CourseID";
			parameters[2].Value = PageSize;
			parameters[3].Value = PageIndex;
			parameters[4].Value = 0;
			parameters[5].Value = 0;
			parameters[6].Value = strWhere;	
			return DbHelperSQL.RunProcedure("UP_GetRecordByPage",parameters,"ds");
		}*/

		#endregion  BasicMethod
		#region  ExtensionMethod

		#endregion  ExtensionMethod
	}
}

