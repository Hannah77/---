﻿using System;
namespace Maticsoft.Model
{
	/// <summary>
	/// TeachTable:实体类(属性说明自动提取数据库字段的描述信息)
	/// </summary>
	[Serializable]
	public partial class TeachTable
	{
		public TeachTable()
		{}
		#region Model
		private string _courseid;
		private string _teacherid;
		private int? _location;
		/// <summary>
		/// 
		/// </summary>
		public string CourseID
		{
			set{ _courseid=value;}
			get{return _courseid;}
		}
		/// <summary>
		/// 
		/// </summary>
		public string TeacherID
		{
			set{ _teacherid=value;}
			get{return _teacherid;}
		}
		/// <summary>
		/// 
		/// </summary>
		public int? Location
		{
			set{ _location=value;}
			get{return _location;}
		}
		#endregion Model

	}
}

