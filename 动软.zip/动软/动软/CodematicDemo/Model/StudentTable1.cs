﻿using System;
namespace Maticsoft.Model
{
	/// <summary>
	/// StudentTable1:实体类(属性说明自动提取数据库字段的描述信息)
	/// </summary>
	[Serializable]
	public partial class StudentTable1
	{
		public StudentTable1()
		{}
		#region Model
		private string _studentid;
		private string _studentname;
		private string _studentsex;
		private DateTime? _studentbithday;
		private string _class;
		/// <summary>
		/// 
		/// </summary>
		public string StudentID
		{
			set{ _studentid=value;}
			get{return _studentid;}
		}
		/// <summary>
		/// 
		/// </summary>
		public string StudentName
		{
			set{ _studentname=value;}
			get{return _studentname;}
		}
		/// <summary>
		/// 
		/// </summary>
		public string StudentSex
		{
			set{ _studentsex=value;}
			get{return _studentsex;}
		}
		/// <summary>
		/// 
		/// </summary>
		public DateTime? StudentBithday
		{
			set{ _studentbithday=value;}
			get{return _studentbithday;}
		}
		/// <summary>
		/// 
		/// </summary>
		public string Class
		{
			set{ _class=value;}
			get{return _class;}
		}
		#endregion Model

	}
}

