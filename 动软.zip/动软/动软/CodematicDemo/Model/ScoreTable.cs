﻿using System;
namespace Maticsoft.Model
{
	/// <summary>
	/// ScoreTable:实体类(属性说明自动提取数据库字段的描述信息)
	/// </summary>
	[Serializable]
	public partial class ScoreTable
	{
		public ScoreTable()
		{}
		#region Model
		private string _courseid;
		private string _studentid;
		private int? _score;
		/// <summary>
		/// 
		/// </summary>
		public string CourseID
		{
			set{ _courseid=value;}
			get{return _courseid;}
		}
		/// <summary>
		/// 
		/// </summary>
		public string StudentID
		{
			set{ _studentid=value;}
			get{return _studentid;}
		}
		/// <summary>
		/// 
		/// </summary>
		public int? Score
		{
			set{ _score=value;}
			get{return _score;}
		}
		#endregion Model

	}
}

