﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Maticsoft.Web.Logon
{
    public partial class delete : Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            			if (!Page.IsPostBack)
			{
				Maticsoft.BLL.Logon bll=new Maticsoft.BLL.Logon();
				if (Request.Params["id"] != null && Request.Params["id"].Trim() != "")
				{
					string UserID= Request.Params["id"];
					bll.Delete(UserID);
					Response.Redirect("list.aspx");
				}
			}

        }
    }
}