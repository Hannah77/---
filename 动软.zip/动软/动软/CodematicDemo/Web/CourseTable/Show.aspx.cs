﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Text;
namespace Maticsoft.Web.CourseTable
{
    public partial class Show : Page
    {        
        		public string strid=""; 
		protected void Page_Load(object sender, EventArgs e)
		{
			if (!Page.IsPostBack)
			{
				if (Request.Params["id"] != null && Request.Params["id"].Trim() != "")
				{
					strid = Request.Params["id"];
					string CourseID= strid;
					ShowInfo(CourseID);
				}
			}
		}
		
	private void ShowInfo(string CourseID)
	{
		Maticsoft.BLL.CourseTable bll=new Maticsoft.BLL.CourseTable();
		Maticsoft.Model.CourseTable model=bll.GetModel(CourseID);
		this.lblCourseID.Text=model.CourseID;
		this.lblCourseName.Text=model.CourseName;
		this.lblPoint.Text=model.Point;
		this.lblStuNumber.Text=model.StuNumber.ToString();

	}


    }
}
