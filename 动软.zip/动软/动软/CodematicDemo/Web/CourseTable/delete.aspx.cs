﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Maticsoft.Web.CourseTable
{
    public partial class delete : Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            			if (!Page.IsPostBack)
			{
				Maticsoft.BLL.CourseTable bll=new Maticsoft.BLL.CourseTable();
				if (Request.Params["id"] != null && Request.Params["id"].Trim() != "")
				{
					string CourseID= Request.Params["id"];
					bll.Delete(CourseID);
					Response.Redirect("list.aspx");
				}
			}

        }
    }
}