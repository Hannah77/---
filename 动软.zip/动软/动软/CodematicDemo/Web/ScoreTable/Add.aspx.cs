﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Text;
using Maticsoft.Common;
using LTP.Accounts.Bus;
namespace Maticsoft.Web.ScoreTable
{
    public partial class Add : Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
                       
        }

        		protected void btnSave_Click(object sender, EventArgs e)
		{
			
			string strErr="";
			if(this.txtCourseID.Text.Trim().Length==0)
			{
				strErr+="CourseID不能为空！\\n";	
			}
			if(this.txtStudentID.Text.Trim().Length==0)
			{
				strErr+="StudentID不能为空！\\n";	
			}
			if(!PageValidate.IsNumber(txtScore.Text))
			{
				strErr+="Score格式错误！\\n";	
			}

			if(strErr!="")
			{
				MessageBox.Show(this,strErr);
				return;
			}
			string CourseID=this.txtCourseID.Text;
			string StudentID=this.txtStudentID.Text;
			int Score=int.Parse(this.txtScore.Text);

			Maticsoft.Model.ScoreTable model=new Maticsoft.Model.ScoreTable();
			model.CourseID=CourseID;
			model.StudentID=StudentID;
			model.Score=Score;

			Maticsoft.BLL.ScoreTable bll=new Maticsoft.BLL.ScoreTable();
			bll.Add(model);
			Maticsoft.Common.MessageBox.ShowAndRedirect(this,"保存成功！","add.aspx");

		}


        public void btnCancle_Click(object sender, EventArgs e)
        {
            Response.Redirect("list.aspx");
        }
    }
}
