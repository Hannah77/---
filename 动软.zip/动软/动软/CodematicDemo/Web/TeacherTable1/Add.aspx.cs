﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Text;
using Maticsoft.Common;
using LTP.Accounts.Bus;
namespace Maticsoft.Web.TeacherTable1
{
    public partial class Add : Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
                       
        }

        		protected void btnSave_Click(object sender, EventArgs e)
		{
			
			string strErr="";
			if(this.txtTeacherID.Text.Trim().Length==0)
			{
				strErr+="TeacherID不能为空！\\n";	
			}
			if(this.txtTeacherName.Text.Trim().Length==0)
			{
				strErr+="TeacherName不能为空！\\n";	
			}
			if(this.txtTeacherSex.Text.Trim().Length==0)
			{
				strErr+="TeacherSex不能为空！\\n";	
			}
			if(!PageValidate.IsDateTime(txtTeacherBirthday.Text))
			{
				strErr+="TeacherBirthday格式错误！\\n";	
			}
			if(this.txtPost.Text.Trim().Length==0)
			{
				strErr+="Post不能为空！\\n";	
			}
			if(this.txtDepartment.Text.Trim().Length==0)
			{
				strErr+="Department不能为空！\\n";	
			}

			if(strErr!="")
			{
				MessageBox.Show(this,strErr);
				return;
			}
			string TeacherID=this.txtTeacherID.Text;
			string TeacherName=this.txtTeacherName.Text;
			string TeacherSex=this.txtTeacherSex.Text;
			DateTime TeacherBirthday=DateTime.Parse(this.txtTeacherBirthday.Text);
			string Post=this.txtPost.Text;
			string Department=this.txtDepartment.Text;

			Maticsoft.Model.TeacherTable1 model=new Maticsoft.Model.TeacherTable1();
			model.TeacherID=TeacherID;
			model.TeacherName=TeacherName;
			model.TeacherSex=TeacherSex;
			model.TeacherBirthday=TeacherBirthday;
			model.Post=Post;
			model.Department=Department;

			Maticsoft.BLL.TeacherTable1 bll=new Maticsoft.BLL.TeacherTable1();
			bll.Add(model);
			Maticsoft.Common.MessageBox.ShowAndRedirect(this,"保存成功！","add.aspx");

		}


        public void btnCancle_Click(object sender, EventArgs e)
        {
            Response.Redirect("list.aspx");
        }
    }
}
