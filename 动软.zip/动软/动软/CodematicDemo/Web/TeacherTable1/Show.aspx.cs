﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Text;
namespace Maticsoft.Web.TeacherTable1
{
    public partial class Show : Page
    {        
        		public string strid=""; 
		protected void Page_Load(object sender, EventArgs e)
		{
			if (!Page.IsPostBack)
			{
				if (Request.Params["id"] != null && Request.Params["id"].Trim() != "")
				{
					strid = Request.Params["id"];
					string TeacherID= strid;
					ShowInfo(TeacherID);
				}
			}
		}
		
	private void ShowInfo(string TeacherID)
	{
		Maticsoft.BLL.TeacherTable1 bll=new Maticsoft.BLL.TeacherTable1();
		Maticsoft.Model.TeacherTable1 model=bll.GetModel(TeacherID);
		this.lblTeacherID.Text=model.TeacherID;
		this.lblTeacherName.Text=model.TeacherName;
		this.lblTeacherSex.Text=model.TeacherSex;
		this.lblTeacherBirthday.Text=model.TeacherBirthday.ToString();
		this.lblPost.Text=model.Post;
		this.lblDepartment.Text=model.Department;

	}


    }
}
