﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Maticsoft.Web.TeacherTable1
{
    public partial class delete : Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            			if (!Page.IsPostBack)
			{
				Maticsoft.BLL.TeacherTable1 bll=new Maticsoft.BLL.TeacherTable1();
				if (Request.Params["id"] != null && Request.Params["id"].Trim() != "")
				{
					string TeacherID= Request.Params["id"];
					bll.Delete(TeacherID);
					Response.Redirect("list.aspx");
				}
			}

        }
    }
}