﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Text;
using Maticsoft.Common;
using LTP.Accounts.Bus;
namespace Maticsoft.Web.TeachTable
{
    public partial class Add : Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
                       
        }

        		protected void btnSave_Click(object sender, EventArgs e)
		{
			
			string strErr="";
			if(this.txtCourseID.Text.Trim().Length==0)
			{
				strErr+="CourseID不能为空！\\n";	
			}
			if(this.txtTeacherID.Text.Trim().Length==0)
			{
				strErr+="TeacherID不能为空！\\n";	
			}
			if(!PageValidate.IsNumber(txtLocation.Text))
			{
				strErr+="Location格式错误！\\n";	
			}

			if(strErr!="")
			{
				MessageBox.Show(this,strErr);
				return;
			}
			string CourseID=this.txtCourseID.Text;
			string TeacherID=this.txtTeacherID.Text;
			int Location=int.Parse(this.txtLocation.Text);

			Maticsoft.Model.TeachTable model=new Maticsoft.Model.TeachTable();
			model.CourseID=CourseID;
			model.TeacherID=TeacherID;
			model.Location=Location;

			Maticsoft.BLL.TeachTable bll=new Maticsoft.BLL.TeachTable();
			bll.Add(model);
			Maticsoft.Common.MessageBox.ShowAndRedirect(this,"保存成功！","add.aspx");

		}


        public void btnCancle_Click(object sender, EventArgs e)
        {
            Response.Redirect("list.aspx");
        }
    }
}
